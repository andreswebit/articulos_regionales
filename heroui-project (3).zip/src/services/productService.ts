import api, { handleApiResponse } from './api';
import { Product, ApiResponse } from '../types';
import { mockProducts } from './mockData';

// Simulación de respuestas de API
const simulateApiCall = <T>(data: T, delay: number = 800): Promise<T> => {
  return new Promise((resolve) => {
    setTimeout(() => resolve(data), delay);
  });
};

// Servicio de productos
export const productService = {
  // Obtener todos los productos
  getAllProducts: async (): Promise<ApiResponse<Product[]>> => {
    try {
      // En un entorno real, esto sería una llamada a la API
      // return handleApiResponse(api.get('/products'));
      
      // Simulación de API para desarrollo
      const response = await simulateApiCall(mockProducts);
      return { success: true, data: response };
    } catch (error) {
      console.error('Error al obtener productos:', error);
      return { success: false, error: 'Error al obtener productos' };
    }
  },
  
  // Obtener un producto por ID
  getProductById: async (id: number): Promise<ApiResponse<Product>> => {
    try {
      // En un entorno real, esto sería una llamada a la API
      // return handleApiResponse(api.get(`/products/${id}`));
      
      // Simulación de API para desarrollo
      const product = mockProducts.find(p => p.id === id);
      
      if (product) {
        const response = await simulateApiCall(product);
        return { success: true, data: response };
      }
      
      return { success: false, error: 'Producto no encontrado' };
    } catch (error) {
      console.error(`Error al obtener producto ${id}:`, error);
      return { success: false, error: 'Error al obtener el producto' };
    }
  },
  
  // Obtener productos por categoría
  getProductsByCategory: async (category: string): Promise<ApiResponse<Product[]>> => {
    try {
      // En un entorno real, esto sería una llamada a la API
      // return handleApiResponse(api.get(`/products/category/${category}`));
      
      // Simulación de API para desarrollo
      const products = mockProducts.filter(p => p.category === category);
      const response = await simulateApiCall(products);
      return { success: true, data: response };
    } catch (error) {
      console.error(`Error al obtener productos de categoría ${category}:`, error);
      return { success: false, error: 'Error al obtener productos por categoría' };
    }
  },
  
  // Buscar productos
  searchProducts: async (query: string): Promise<ApiResponse<Product[]>> => {
    try {
      // En un entorno real, esto sería una llamada a la API
      // return handleApiResponse(api.get(`/products/search?q=${query}`));
      
      // Simulación de API para desarrollo
      const products = mockProducts.filter(p => 
        p.name.toLowerCase().includes(query.toLowerCase()) || 
        p.description?.toLowerCase().includes(query.toLowerCase()) ||
        p.region.toLowerCase().includes(query.toLowerCase())
      );
      
      const response = await simulateApiCall(products);
      return { success: true, data: response };
    } catch (error) {
      console.error(`Error al buscar productos con "${query}":`, error);
      return { success: false, error: 'Error al buscar productos' };
    }
  }
};
