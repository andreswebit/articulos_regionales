import React from "react";
import { Card, CardBody, CardHeader, CardFooter, Button, Image } from "@heroui/react";
import { Icon } from "@iconify/react";

const videos = [
  {
    id: 1,
    title: "Artesanía en Cerámica de Salta",
    description: "Descubre el proceso tradicional de elaboración de cerámica en los valles salteños.",
    thumbnail: "https://img.heroui.chat/image/places?w=800&h=450&u=11",
    duration: "5:42",
    views: "2.4k",
    date: "15 de Marzo, 2023"
  },
  {
    id: 2,
    title: "Tejidos Ancestrales de Jujuy",
    description: "Conoce las técnicas milenarias de tejido que se mantienen vivas en las comunidades de la Quebrada.",
    thumbnail: "https://img.heroui.chat/image/places?w=800&h=450&u=12",
    duration: "8:17",
    views: "3.8k",
    date: "22 de Abril, 2023"
  },
  {
    id: 3,
    title: "Ruta del Vino en Cafayate",
    description: "Un recorrido por los viñedos más importantes de la región y el proceso de elaboración del Torrontés.",
    thumbnail: "https://img.heroui.chat/image/places?w=800&h=450&u=13",
    duration: "12:05",
    views: "5.1k",
    date: "7 de Mayo, 2023"
  },
  {
    id: 4,
    title: "Carnaval Humahuaqueño",
    description: "Vive la explosión de color y música del tradicional carnaval en las calles de Humahuaca.",
    thumbnail: "https://img.heroui.chat/image/places?w=800&h=450&u=14",
    duration: "7:23",
    views: "4.7k",
    date: "18 de Junio, 2023"
  },
  {
    id: 5,
    title: "Gastronomía del Norte",
    description: "Un viaje culinario por los sabores más auténticos de la cocina norteña argentina.",
    thumbnail: "https://img.heroui.chat/image/food?w=800&h=450&u=15",
    duration: "9:51",
    views: "3.2k",
    date: "3 de Julio, 2023"
  },
  {
    id: 6,
    title: "Instrumentos Andinos",
    description: "La fabricación artesanal de instrumentos musicales tradicionales de la región andina.",
    thumbnail: "https://img.heroui.chat/image/places?w=800&h=450&u=16",
    duration: "6:38",
    views: "2.9k",
    date: "29 de Agosto, 2023"
  }
];

export const VideosPage: React.FC = () => {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Videos del Norte Argentino</h1>
        <p className="text-default-500 mt-2">
          Explora nuestra colección de videos sobre artesanías, tradiciones y cultura del norte argentino.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {videos.map((video) => (
          <Card key={video.id} isPressable shadow="sm" className="border border-default-200">
            <CardHeader className="p-0 relative">
              <Image
                removeWrapper
                alt={video.title}
                className="w-full h-48 object-cover"
                src={video.thumbnail}
              />
              <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded-md">
                {video.duration}
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-12 h-12 bg-black/50 rounded-full flex items-center justify-center hover:bg-primary/80 transition-colors cursor-pointer">
                  <Icon icon="lucide:play" className="text-white" width={24} />
                </div>
              </div>
            </CardHeader>
            <CardBody className="space-y-2">
              <h3 className="font-bold text-base line-clamp-1">{video.title}</h3>
              <p className="text-default-500 text-sm line-clamp-2">{video.description}</p>
              <div className="flex items-center justify-between text-xs text-default-500">
                <span className="flex items-center gap-1">
                  <Icon icon="lucide:eye" width={14} />
                  {video.views} visualizaciones
                </span>
                <span>{video.date}</span>
              </div>
            </CardBody>
            <CardFooter>
              <Button 
                fullWidth 
                color="primary" 
                variant="flat" 
                size="sm"
                startContent={<Icon icon="lucide:play" width={16} />}
              >
                Ver Video
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};