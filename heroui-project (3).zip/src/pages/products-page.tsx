import React from "react";
import { ProductGrid } from "../components/product-grid";

export const ProductsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Nuestros Productos</h1>
        <p className="text-default-500 mt-2">
          Descubre nuestra selección de artesanías y productos regionales del norte argentino.
        </p>
      </div>
      
      <ProductGrid />
    </div>
  );
};