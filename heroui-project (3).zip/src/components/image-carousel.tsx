import React from "react";
import { Card, CardBody, Image, Button } from "@heroui/react";
import { Icon } from "@iconify/react";

interface CarouselImage {
  src: string;
  alt: string;
  title?: string;
  description?: string;
}

interface ImageCarouselProps {
  images: CarouselImage[];
  autoPlay?: boolean;
  interval?: number;
}

export const ImageCarousel: React.FC<ImageCarouselProps> = ({ 
  images, 
  autoPlay = true, 
  interval = 5000 
}) => {
  const [currentIndex, setCurrentIndex] = React.useState(0);
  const timerRef = React.useRef<number | null>(null);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  React.useEffect(() => {
    if (autoPlay) {
      timerRef.current = window.setInterval(() => {
        nextSlide();
      }, interval);
    }

    return () => {
      if (timerRef.current !== null) {
        clearInterval(timerRef.current);
      }
    };
  }, [autoPlay, interval]);

  return (
    <Card className="w-full overflow-hidden relative">
      <CardBody className="p-0 overflow-hidden">
        <div className="relative h-[300px] md:h-[400px]">
          {images.map((image, index) => (
            <div
              key={index}
              className={`absolute top-0 left-0 w-full h-full transition-opacity duration-500 ease-in-out ${
                index === currentIndex ? "opacity-100" : "opacity-0 pointer-events-none"
              }`}
            >
              <Image
                removeWrapper
                alt={image.alt}
                className="w-full h-full object-cover"
                src={image.src}
              />
              {(image.title || image.description) && (
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 text-white">
                  {image.title && <h3 className="text-xl font-bold">{image.title}</h3>}
                  {image.description && <p className="text-sm mt-1">{image.description}</p>}
                </div>
              )}
            </div>
          ))}
        </div>

        <Button
          isIconOnly
          className="absolute top-1/2 left-2 -translate-y-1/2 bg-black/30 text-white hover:bg-black/50"
          size="sm"
          variant="flat"
          onPress={prevSlide}
        >
          <Icon icon="lucide:chevron-left" width={20} />
        </Button>

        <Button
          isIconOnly
          className="absolute top-1/2 right-2 -translate-y-1/2 bg-black/30 text-white hover:bg-black/50"
          size="sm"
          variant="flat"
          onPress={nextSlide}
        >
          <Icon icon="lucide:chevron-right" width={20} />
        </Button>

        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-1">
          {images.map((_, index) => (
            <button
              key={index}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentIndex ? "bg-white w-4" : "bg-white/50"
              }`}
              onClick={() => goToSlide(index)}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </CardBody>
    </Card>
  );
};