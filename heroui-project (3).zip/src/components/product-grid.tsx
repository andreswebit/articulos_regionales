import React, { useEffect, useState } from "react";
import { Card, CardBody, CardFooter, Button, Image, Spinner } from "@heroui/react";
import { Icon } from "@iconify/react";
import { Product } from "../types";
import { productService } from "../services/productService";
import { useCart } from "../context/CartContext";

const products = [
  {
    id: 1,
    name: "Poncho Salteño",
    price: 12500,
    image: "https://img.heroui.chat/image/clothing?w=400&h=400&u=1",
    region: "Salta"
  },
  {
    id: 2,
    name: "Cerámica Diaguita",
    price: 8900,
    image: "https://img.heroui.chat/image/furniture?w=400&h=400&u=2",
    region: "Tucumán"
  },
  {
    id: 3,
    name: "Alfajores Jujeños",
    price: 3200,
    image: "https://img.heroui.chat/image/food?w=400&h=400&u=3",
    region: "Jujuy"
  },
  {
    id: 4,
    name: "Mate Artesanal",
    price: 5700,
    image: "https://img.heroui.chat/image/furniture?w=400&h=400&u=4",
    region: "Catamarca"
  },
  {
    id: 5,
    name: "Vino Torrontés",
    price: 4500,
    image: "https://img.heroui.chat/image/food?w=400&h=400&u=5",
    region: "Salta"
  },
  {
    id: 6,
    name: "Tejido Andino",
    price: 9800,
    image: "https://img.heroui.chat/image/clothing?w=400&h=400&u=6",
    region: "Jujuy"
  },
  {
    id: 7,
    name: "Dulce de Cayote",
    price: 2800,
    image: "https://img.heroui.chat/image/food?w=400&h=400&u=7",
    region: "Santiago del Estero"
  },
  {
    id: 8,
    name: "Instrumentos Andinos",
    price: 15000,
    image: "https://img.heroui.chat/image/furniture?w=400&h=400&u=8",
    region: "Jujuy"
  }
];

export const ProductGrid: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { addToCart } = useCart();

  useEffect(() => {
    const loadProducts = async () => {
      setIsLoading(true);
      try {
        const response = await productService.getAllProducts();
        if (response.success && response.data) {
          setProducts(response.data);
        }
      } catch (error) {
        console.error("Error al cargar productos:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadProducts();
  }, []);

  const handleAddToCart = (product: Product) => {
    addToCart(product, 1);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Spinner size="lg" color="primary" />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 py-8">
      {products.map((product) => (
        <Card shadow="sm" key={product.id} isPressable className="border border-default-200">
          <CardBody className="p-0 overflow-hidden">
            <Image
              removeWrapper
              alt={product.name}
              className="w-full h-48 object-cover"
              src={product.image}
            />
          </CardBody>
          <CardFooter className="flex flex-col items-start text-small gap-2">
            <div className="flex items-center gap-1">
              <Icon icon="lucide:map-pin" width={14} className="text-default-500" />
              <span className="text-default-500">{product.region}</span>
            </div>
            <b className="text-foreground text-medium">{product.name}</b>
            <p className="text-default-500">$ {product.price.toLocaleString()}</p>
            <Button 
              color="primary" 
              size="sm" 
              className="w-full mt-2"
              startContent={<Icon icon="lucide:shopping-cart" width={16} />}
              onPress={() => handleAddToCart(product)}
            >
              Agregar
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
};