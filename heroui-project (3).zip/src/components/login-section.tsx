import React, { useState } from "react";
import { Card, CardBody, CardHeader, Input, Button, Checkbox, Divider, Tabs, Tab } from "@heroui/react";
import { Icon } from "@iconify/react";
import { useAuth } from "../context/AuthContext";
import { useHistory } from "react-router-dom";

export const LoginSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState("login");
  const history = useHistory();
  const { login, register } = useAuth();

  // Login state
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Register state
  const [registerName, setRegisterName] = useState("");
  const [registerEmail, setRegisterEmail] = useState("");
  const [registerPassword, setRegisterPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isRegisterLoading, setIsRegisterLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const success = await login({
      email,
      password,
      rememberMe
    });
    
    setIsLoading(false);
    
    if (success) {
      history.push("/");
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsRegisterLoading(true);
    
    const success = await register({
      name: registerName,
      email: registerEmail,
      password: registerPassword,
      confirmPassword
    });
    
    setIsRegisterLoading(false);
    
    if (success) {
      history.push("/");
    }
  };

  return (
    <div className="py-4 flex justify-center">
      <Card className="max-w-md w-full">
        <CardBody>
          <Tabs 
            selectedKey={activeTab} 
            onSelectionChange={setActiveTab as any}
            variant="underlined"
            color="primary"
            className="mb-4"
          >
            <Tab 
              key="login" 
              title="Iniciar Sesión"
            >
              <form onSubmit={handleLogin} className="space-y-6 py-4">
                <Input
                  label="Correo Electrónico"
                  placeholder="tucorreo@ejemplo.com"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  variant="bordered"
                  isRequired
                  startContent={<Icon icon="lucide:mail" className="text-default-400" width={18} />}
                />
                
                <Input
                  label="Contraseña"
                  placeholder="Ingresa tu contraseña"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  variant="bordered"
                  isRequired
                  startContent={<Icon icon="lucide:lock" className="text-default-400" width={18} />}
                />
                
                <div className="flex items-center justify-between">
                  <Checkbox 
                    isSelected={rememberMe} 
                    onValueChange={setRememberMe}
                    size="sm"
                  >
                    <span className="text-small">Recordarme</span>
                  </Checkbox>
                  <Button variant="light" size="sm" className="text-primary">
                    ¿Olvidaste tu contraseña?
                  </Button>
                </div>
                
                <Button 
                  type="submit" 
                  color="primary" 
                  className="w-full" 
                  isLoading={isLoading}
                >
                  Iniciar Sesión
                </Button>
                
                <Divider className="my-4" />
                
                <div className="space-y-4">
                  <Button 
                    className="w-full" 
                    variant="bordered"
                    startContent={<Icon icon="logos:google-icon" width={18} />}
                  >
                    Continuar con Google
                  </Button>
                  
                  <Button 
                    className="w-full" 
                    variant="bordered"
                    startContent={<Icon icon="logos:facebook" width={18} />}
                  >
                    Continuar con Facebook
                  </Button>
                </div>
              </form>
            </Tab>
            <Tab 
              key="register" 
              title="Registrarse"
            >
              <form onSubmit={handleRegister} className="space-y-6 py-4">
                <Input
                  label="Nombre Completo"
                  placeholder="Tu nombre"
                  type="text"
                  value={registerName}
                  onChange={(e) => setRegisterName(e.target.value)}
                  variant="bordered"
                  isRequired
                  startContent={<Icon icon="lucide:user" className="text-default-400" width={18} />}
                />
                
                <Input
                  label="Correo Electrónico"
                  placeholder="tucorreo@ejemplo.com"
                  type="email"
                  value={registerEmail}
                  onChange={(e) => setRegisterEmail(e.target.value)}
                  variant="bordered"
                  isRequired
                  startContent={<Icon icon="lucide:mail" className="text-default-400" width={18} />}
                />
                
                <Input
                  label="Contraseña"
                  placeholder="Crea una contraseña"
                  type="password"
                  value={registerPassword}
                  onChange={(e) => setRegisterPassword(e.target.value)}
                  variant="bordered"
                  isRequired
                  startContent={<Icon icon="lucide:lock" className="text-default-400" width={18} />}
                />
                
                <Input
                  label="Confirmar Contraseña"
                  placeholder="Repite tu contraseña"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  variant="bordered"
                  isRequired
                  startContent={<Icon icon="lucide:lock" className="text-default-400" width={18} />}
                />
                
                <Button 
                  type="submit" 
                  color="primary" 
                  className="w-full" 
                  isLoading={isRegisterLoading}
                >
                  Crear Cuenta
                </Button>
                
                <p className="text-center text-small text-default-500">
                  Al registrarte, aceptas nuestros <Button size="sm" variant="light" className="text-primary p-0">Términos y Condiciones</Button> y <Button size="sm" variant="light" className="text-primary p-0">Política de Privacidad</Button>.
                </p>
              </form>
            </Tab>
          </Tabs>
        </CardBody>
      </Card>
    </div>
  );
};